# 🔐 Password Manager CLI

A local, encrypted command-line password manager. Your master password
never leaves your machine and is never stored — a key is derived from it
on the fly using PBKDF2, and all entries are encrypted with Fernet (AES-128
in CBC mode with HMAC authentication).

## Features

- Master-password-protected vault (nothing stored in plaintext)
- Add, retrieve, list, and delete password entries
- Cryptographically secure random password generator
- Vault encrypted at rest using `cryptography`'s `Fernet` + PBKDF2-derived key
- Vault file lives locally in a `.vault/` folder (gitignored by default)

## Setup

```bash
git clone <your-repo-url>
cd password-manager
pip install -r requirements.txt
python password_manager.py init
```

You'll be prompted to create a master password. **If you forget it, your
data cannot be recovered** — there is no backdoor, by design.

## Usage

**Add a password:**
```bash
python password_manager.py add github myusername "MySecurePass123!"
```

**Retrieve a password:**
```bash
python password_manager.py get github
```

**List all saved entries (names only, not passwords):**
```bash
python password_manager.py list
```

**Delete an entry:**
```bash
python password_manager.py delete github
```

**Generate a strong random password:**
```bash
python password_manager.py generate --length 20
```

## How it works

1. On `init`, a random 16-byte salt is generated and saved to `.vault/salt.bin`.
2. Your master password + salt are run through PBKDF2-HMAC-SHA256
   (480,000 iterations) to derive a 256-bit encryption key.
3. That key is used with `Fernet` to encrypt/decrypt a JSON blob containing
   all your entries, stored in `.vault/vault.enc`.
4. Every command that touches your data re-derives the key from your master
   password — the key itself is never written to disk.

## Security notes

- This is a **learning/portfolio project**, not audited production software.
  For real-world use, consider established tools like Bitwarden or 1Password.
- The `.gitignore` excludes `.vault/` so you don't accidentally commit your
  encrypted data (or worse, your salt) to a public repo.

## Possible extensions

- Add clipboard copy support (`pyperclip`) instead of printing passwords to terminal
- Add a password strength checker
- Build a Tkinter or Textual-based GUI
- Add auto-lock after inactivity
