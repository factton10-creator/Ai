#!/usr/bin/env python3
"""
Password Manager CLI
---------------------
A local, encrypted password manager. All entries are encrypted with a key
derived from a master password (PBKDF2 + Fernet/AES). Nothing is ever
stored in plaintext.

First-time setup:
    python password_manager.py init

Usage:
    python password_manager.py add github myuser mypassword123
    python password_manager.py get github
    python password_manager.py list
    python password_manager.py delete github
    python password_manager.py generate --length 20
"""

import argparse
import base64
import getpass
import json
import os
import secrets
import string
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

VAULT_DIR = Path(__file__).parent / ".vault"
SALT_FILE = VAULT_DIR / "salt.bin"
VAULT_FILE = VAULT_DIR / "vault.enc"
PBKDF2_ITERATIONS = 480_000


def derive_key(master_password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(master_password.encode()))


def init_vault():
    if VAULT_FILE.exists():
        print("Vault already exists. Delete .vault/ manually to reset (this destroys all data).")
        return

    VAULT_DIR.mkdir(exist_ok=True)

    master_password = getpass.getpass("Create a master password: ")
    confirm = getpass.getpass("Confirm master password: ")
    if master_password != confirm:
        print("Passwords do not match. Try again.")
        return

    salt = os.urandom(16)
    SALT_FILE.write_bytes(salt)

    key = derive_key(master_password, salt)
    fernet = Fernet(key)
    empty_vault = fernet.encrypt(json.dumps({}).encode())
    VAULT_FILE.write_bytes(empty_vault)

    print(f"Vault created at {VAULT_FILE}")
    print("IMPORTANT: If you forget your master password, your data cannot be recovered.")


def unlock_vault() -> tuple[dict, Fernet]:
    if not VAULT_FILE.exists():
        print("No vault found. Run `python password_manager.py init` first.")
        raise SystemExit(1)

    master_password = getpass.getpass("Master password: ")
    salt = SALT_FILE.read_bytes()
    key = derive_key(master_password, salt)
    fernet = Fernet(key)

    try:
        data = json.loads(fernet.decrypt(VAULT_FILE.read_bytes()).decode())
    except InvalidToken:
        print("Incorrect master password.")
        raise SystemExit(1)

    return data, fernet


def save_vault(data: dict, fernet: Fernet):
    encrypted = fernet.encrypt(json.dumps(data).encode())
    VAULT_FILE.write_bytes(encrypted)


def add_entry(name: str, username: str, password: str):
    data, fernet = unlock_vault()
    if name in data:
        overwrite = input(f"Entry '{name}' already exists. Overwrite? [y/N]: ").lower()
        if overwrite != "y":
            print("Cancelled.")
            return
    data[name] = {"username": username, "password": password}
    save_vault(data, fernet)
    print(f"Saved entry for '{name}'.")


def get_entry(name: str):
    data, _ = unlock_vault()
    entry = data.get(name)
    if not entry:
        print(f"No entry found for '{name}'.")
        return
    print(f"Site/App : {name}")
    print(f"Username : {entry['username']}")
    print(f"Password : {entry['password']}")


def list_entries():
    data, _ = unlock_vault()
    if not data:
        print("Vault is empty.")
        return
    print(f"{'Name':<25}{'Username'}")
    print("-" * 50)
    for name, entry in sorted(data.items()):
        print(f"{name:<25}{entry['username']}")


def delete_entry(name: str):
    data, fernet = unlock_vault()
    if name not in data:
        print(f"No entry found for '{name}'.")
        return
    del data[name]
    save_vault(data, fernet)
    print(f"Deleted entry for '{name}'.")


def generate_password(length: int = 16, use_symbols: bool = True) -> str:
    alphabet = string.ascii_letters + string.digits
    if use_symbols:
        alphabet += "!@#$%^&*()-_=+"
    password = "".join(secrets.choice(alphabet) for _ in range(length))
    print(password)
    return password


def main():
    parser = argparse.ArgumentParser(description="A local encrypted password manager.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("init", help="Create a new encrypted vault")

    add_parser = subparsers.add_parser("add", help="Add or update a password entry")
    add_parser.add_argument("name", help="Name of the site/app (e.g. github)")
    add_parser.add_argument("username", help="Username or email")
    add_parser.add_argument("password", help="Password to store")

    get_parser = subparsers.add_parser("get", help="Retrieve a password entry")
    get_parser.add_argument("name", help="Name of the site/app")

    subparsers.add_parser("list", help="List all stored entry names")

    delete_parser = subparsers.add_parser("delete", help="Delete a password entry")
    delete_parser.add_argument("name", help="Name of the site/app")

    gen_parser = subparsers.add_parser("generate", help="Generate a strong random password")
    gen_parser.add_argument("--length", type=int, default=16, help="Password length (default 16)")
    gen_parser.add_argument("--no-symbols", action="store_true", help="Exclude special characters")

    args = parser.parse_args()

    if args.command == "init":
        init_vault()
    elif args.command == "add":
        add_entry(args.name, args.username, args.password)
    elif args.command == "get":
        get_entry(args.name)
    elif args.command == "list":
        list_entries()
    elif args.command == "delete":
        delete_entry(args.name)
    elif args.command == "generate":
        generate_password(args.length, use_symbols=not args.no_symbols)


if __name__ == "__main__":
    main()
