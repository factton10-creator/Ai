#!/usr/bin/env python3
"""
Web Scraper
-----------
Scrapes book listings (title, price, rating, availability) from
books.toscrape.com — a site built specifically for scraping practice —
and stores each run's snapshot in a local SQLite database with a
timestamp, so price/rating trends can be tracked over time.

Usage:
    python scraper.py                  # scrape default number of pages
    python scraper.py --pages 5        # scrape more pages
"""

import argparse
import re
import sqlite3
import time
from datetime import datetime
from pathlib import Path

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/catalogue/page-{page}.html"
DB_PATH = Path(__file__).parent / "scraped_data.db"
HEADERS = {"User-Agent": "Mozilla/5.0 (educational scraping project)"}

RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}


def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS book_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scraped_at TEXT NOT NULL,
                title TEXT NOT NULL,
                price REAL NOT NULL,
                rating INTEGER,
                availability TEXT
            )
            """
        )


def parse_price(price_text: str) -> float:
    match = re.search(r"[\d.]+", price_text)
    return float(match.group()) if match else 0.0


def scrape_page(page_number: int):
    url = BASE_URL.format(page=page_number)
    response = requests.get(url, headers=HEADERS, timeout=10)
    if response.status_code != 200:
        return None

    soup = BeautifulSoup(response.text, "html.parser")
    books = []

    for article in soup.select("article.product_pod"):
        title = article.h3.a["title"]
        price_text = article.select_one(".price_color").text
        price = parse_price(price_text)

        rating_class = article.select_one(".star-rating")["class"]
        rating_word = next((c for c in rating_class if c != "star-rating"), None)
        rating = RATING_MAP.get(rating_word, 0)

        availability = article.select_one(".availability").text.strip()

        books.append(
            {
                "title": title,
                "price": price,
                "rating": rating,
                "availability": availability,
            }
        )

    return books


def save_books(books: list, scraped_at: str):
    with sqlite3.connect(DB_PATH) as conn:
        conn.executemany(
            """
            INSERT INTO book_snapshots (scraped_at, title, price, rating, availability)
            VALUES (:scraped_at, :title, :price, :rating, :availability)
            """,
            [{**book, "scraped_at": scraped_at} for book in books],
        )


def run_scrape(max_pages: int, delay: float = 1.0):
    init_db()
    scraped_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_books = 0

    for page in range(1, max_pages + 1):
        print(f"Scraping page {page}...")
        books = scrape_page(page)
        if not books:
            print(f"No more data found after page {page - 1}. Stopping.")
            break
        save_books(books, scraped_at)
        total_books += len(books)
        time.sleep(delay)  # be polite to the server

    print(f"\nDone. Scraped {total_books} book listings at {scraped_at}.")
    print(f"Data saved to {DB_PATH}")


def main():
    parser = argparse.ArgumentParser(
        description="Scrape book price/rating data from books.toscrape.com"
    )
    parser.add_argument("--pages", type=int, default=3, help="Number of catalogue pages to scrape")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between requests in seconds")
    args = parser.parse_args()

    run_scrape(max_pages=args.pages, delay=args.delay)


if __name__ == "__main__":
    main()
