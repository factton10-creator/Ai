# 🕸️ Web Scraper + Dashboard

Scrapes book listings (title, price, star rating, availability) from
[books.toscrape.com](https://books.toscrape.com) — a site built specifically
for scraping practice — stores each run in a local SQLite database, and
generates a clean, self-contained HTML dashboard with charts.

## Features

- Scrapes multiple catalogue pages with `requests` + `BeautifulSoup`
- Stores every scrape run with a timestamp, so you can track price changes over time
- Generates an HTML dashboard with:
  - Price distribution histogram
  - Average price by star rating
  - Price trend across multiple scrape runs (once you've scraped more than once)
  - Table of the 10 most expensive books
- No server required — the dashboard is a single static HTML file you can open in any browser

## Setup

```bash
git clone <your-repo-url>
cd web-scraper-dashboard
pip install -r requirements.txt
```

## Usage

**1. Scrape data:**
```bash
python scraper.py                  # scrapes 3 pages by default
python scraper.py --pages 10       # scrape more pages
python scraper.py --delay 2        # be extra polite to the server
```

**2. Generate the dashboard:**
```bash
python dashboard.py
python dashboard.py --output my_report.html
```

Then just open the generated `dashboard.html` in your browser.

**3. (Optional) Track trends over time**

Run `scraper.py` again on a different day — the dashboard will automatically
pick up multiple snapshots and plot an average-price trend line.

## How it works

- `scraper.py` fetches each catalogue page, parses book cards with BeautifulSoup,
  extracts title/price/rating/availability, and appends a timestamped row per
  book to `scraped_data.db` (SQLite).
- `dashboard.py` reads all historical data, builds matplotlib charts, encodes
  them as base64 PNGs, and embeds them directly into a single HTML file —
  no separate image files or web server needed.

## Notes on responsible scraping

- `books.toscrape.com` is explicitly designed for scraping practice, so this
  is safe to run freely.
- If you adapt this to scrape a real site, always check its `robots.txt` and
  terms of service, add delays between requests (`--delay`), and avoid
  hammering the server.

## Possible extensions

- Point it at a real e-commerce site's public product pages and track price drops
- Add email/Slack alerts when a tracked price drops below a threshold
- Swap the static HTML dashboard for a live Streamlit or Flask app
- Add pagination/filtering to the book table
