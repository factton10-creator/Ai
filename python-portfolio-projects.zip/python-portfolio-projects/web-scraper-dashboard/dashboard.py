#!/usr/bin/env python3
"""
Dashboard Generator
--------------------
Reads scraped book data from scraped_data.db and produces a self-contained
HTML dashboard with charts (price distribution, average price by rating,
and price trend across scrape runs if you've scraped more than once).

Usage:
    python dashboard.py
    python dashboard.py --output report.html
"""

import argparse
import base64
import sqlite3
from io import BytesIO
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # no GUI backend needed
import matplotlib.pyplot as plt

DB_PATH = Path(__file__).parent / "scraped_data.db"


def fig_to_base64(fig) -> str:
    buffer = BytesIO()
    fig.savefig(buffer, format="png", bbox_inches="tight", dpi=110)
    buffer.seek(0)
    encoded = base64.b64encode(buffer.read()).decode()
    plt.close(fig)
    return encoded


def load_data():
    if not DB_PATH.exists():
        print("No scraped data found. Run `python scraper.py` first.")
        raise SystemExit(1)

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM book_snapshots ORDER BY scraped_at").fetchall()

    if not rows:
        print("Database exists but has no data yet. Run `python scraper.py` first.")
        raise SystemExit(1)

    return [dict(row) for row in rows]


def build_price_distribution_chart(rows):
    prices = [r["price"] for r in rows]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(prices, bins=20, color="#4C72B0", edgecolor="white")
    ax.set_title("Price Distribution")
    ax.set_xlabel("Price (£)")
    ax.set_ylabel("Number of Books")
    return fig_to_base64(fig)


def build_avg_price_by_rating_chart(rows):
    totals, counts = {}, {}
    for r in rows:
        rating = r["rating"]
        totals[rating] = totals.get(rating, 0) + r["price"]
        counts[rating] = counts.get(rating, 0) + 1

    ratings = sorted(totals.keys())
    averages = [totals[r] / counts[r] for r in ratings]

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar([str(r) for r in ratings], averages, color="#DD8452")
    ax.set_title("Average Price by Star Rating")
    ax.set_xlabel("Rating (stars)")
    ax.set_ylabel("Average Price (£)")
    return fig_to_base64(fig)


def build_price_trend_chart(rows):
    by_date = {}
    for r in rows:
        date = r["scraped_at"]
        by_date.setdefault(date, []).append(r["price"])

    dates = sorted(by_date.keys())
    if len(dates) < 2:
        return None  # not enough history for a trend line

    averages = [sum(by_date[d]) / len(by_date[d]) for d in dates]

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(dates, averages, marker="o", color="#55A868")
    ax.set_title("Average Price Over Scrape Runs")
    ax.set_xlabel("Scrape Timestamp")
    ax.set_ylabel("Average Price (£)")
    ax.tick_params(axis="x", rotation=30)
    return fig_to_base64(fig)


def build_top_books_table(rows, n=10):
    seen = {}
    for r in rows:
        seen[r["title"]] = r  # keep latest snapshot per title
    top = sorted(seen.values(), key=lambda r: -r["price"])[:n]

    rows_html = "".join(
        f"<tr><td>{b['title']}</td><td>£{b['price']:.2f}</td>"
        f"<td>{'★' * b['rating']}{'☆' * (5 - b['rating'])}</td>"
        f"<td>{b['availability']}</td></tr>"
        for b in top
    )
    return rows_html


def generate_html(rows, output_path: Path):
    price_chart = build_price_distribution_chart(rows)
    rating_chart = build_avg_price_by_rating_chart(rows)
    trend_chart = build_price_trend_chart(rows)
    top_books_rows = build_top_books_table(rows)

    total_books = len(set(r["title"] for r in rows))
    avg_price = sum(r["price"] for r in rows) / len(rows)
    scrape_runs = len(set(r["scraped_at"] for r in rows))

    trend_section = (
        f'<div class="chart"><h2>Price Trend Across Scrapes</h2>'
        f'<img src="data:image/png;base64,{trend_chart}"></div>'
        if trend_chart
        else '<p class="note">Scrape more than once (on different days) to see a price trend chart.</p>'
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book Scraper Dashboard</title>
<style>
    body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 0; padding: 40px;
            background: #f5f6fa; color: #2c3e50; }}
    h1 {{ margin-bottom: 4px; }}
    .subtitle {{ color: #7f8c8d; margin-top: 0; }}
    .stats {{ display: flex; gap: 20px; margin: 30px 0; }}
    .stat-card {{ background: white; padding: 20px 30px; border-radius: 10px;
                  box-shadow: 0 1px 4px rgba(0,0,0,0.08); flex: 1; }}
    .stat-card .value {{ font-size: 28px; font-weight: 700; color: #4C72B0; }}
    .stat-card .label {{ color: #7f8c8d; font-size: 14px; }}
    .charts {{ display: flex; flex-wrap: wrap; gap: 20px; }}
    .chart {{ background: white; padding: 20px; border-radius: 10px;
              box-shadow: 0 1px 4px rgba(0,0,0,0.08); flex: 1; min-width: 400px; }}
    .chart img {{ width: 100%; height: auto; }}
    table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 10px;
             overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.08); margin-top: 20px; }}
    th, td {{ padding: 12px 16px; text-align: left; border-bottom: 1px solid #ecf0f1; }}
    th {{ background: #4C72B0; color: white; }}
    .note {{ color: #7f8c8d; font-style: italic; }}
</style>
</head>
<body>
    <h1>📚 Book Scraper Dashboard</h1>
    <p class="subtitle">Data scraped from books.toscrape.com</p>

    <div class="stats">
        <div class="stat-card"><div class="value">{total_books}</div><div class="label">Unique Books Tracked</div></div>
        <div class="stat-card"><div class="value">£{avg_price:.2f}</div><div class="label">Average Price</div></div>
        <div class="stat-card"><div class="value">{scrape_runs}</div><div class="label">Scrape Run(s)</div></div>
    </div>

    <div class="charts">
        <div class="chart"><h2>Price Distribution</h2><img src="data:image/png;base64,{price_chart}"></div>
        <div class="chart"><h2>Avg Price by Rating</h2><img src="data:image/png;base64,{rating_chart}"></div>
    </div>

    {trend_section}

    <h2>Top 10 Most Expensive Books</h2>
    <table>
        <tr><th>Title</th><th>Price</th><th>Rating</th><th>Availability</th></tr>
        {top_books_rows}
    </table>
</body>
</html>
"""
    output_path.write_text(html, encoding="utf-8")
    print(f"Dashboard generated: {output_path.resolve()}")


def main():
    parser = argparse.ArgumentParser(description="Generate an HTML dashboard from scraped book data.")
    parser.add_argument("--output", type=str, default="dashboard.html", help="Output HTML file path")
    args = parser.parse_args()

    rows = load_data()
    generate_html(rows, Path(args.output))


if __name__ == "__main__":
    main()
